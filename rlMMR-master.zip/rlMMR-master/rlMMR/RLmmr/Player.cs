﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RLmmr
{
    public class Player
    {
        
        public string SteamUsername { get; set; } = "";
        public int _1sMMR { get; set; } = -1;
        public int _2sMMR { get; set; } = -1;
        public int _3sMMR { get; set; } = -1;
        public int _soloMMR { get; set; } = -1;
        public int _hoopsMMR { get; set; } = -1;
        public int _rumbleMMR { get; set; } = -1;
        public int _dropshotMMR { get; set; } = -1;
        public int _snowdayMMR { get; set; } = -1;
    }
}
